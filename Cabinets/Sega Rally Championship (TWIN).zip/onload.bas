10 rem Get cab part position and coordinates
20 let head = CabPartsPosition("head")
30 if head = -1 then goto 1000
40 let screen = CabPartsPosition("screen-mock-horizontal")
50 if screen = -1 then goto 1000
60 lets headX, headZ, headH = CabPartsGetGlobalCoordinate(head, "X"), CabPartsGetGlobalCoordinate(head, "Z"), CabPartsGetGlobalCoordinate(head, "Y")
70 call CabPartsEnable(head, 0)
80 end
1000 let error = "some cabinets parts not found in cabinet"
1010 end