10 rem return the player to its previous position
20 rem and height when the player leaves the game
30 call PlayerSetHeight(playerH)
40 call PlayerSetCoordinate("x", playerX)
50 call PlayerSetCoordinate("z", playerZ)
60 end