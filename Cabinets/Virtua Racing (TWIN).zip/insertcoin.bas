10 rem get actual player position x and Z
20 lets playerX, playerZ = PlayerGetCoordinate("x"), PlayerGetCoordinate("z")
30 rem get the player height
40 let playerH = PlayerGetHeight()
 
50 rem change player height at the same of the head object. 
60 rem the head object height is the distance from the ground, like the player.
70 call PlayerSetHeight(headH)
80 rem move the player to the coordinates of the cabinets' head component.
90 call PlayerSetCoordinate("X", headX)
100 call PlayerSetCoordinate("Z", headZ)
110 call PlayerLookAt(screen)
 