
200  CALL CabPartsEnable("btn-P1", 0)
210  END

250  CALL CabPartsEnable("btn-P1", 1)
260  END

1000  IF OR(ControlActive(JOYPAD_LEFT), ControlActive(JOYPAD_RIGHT)) THEN END ELSE CALL CabPartsSetRotation("joy", "Z", -1*DA)
1010  END

1100  IF OR(ControlActive(JOYPAD_LEFT), ControlActive(JOYPAD_RIGHT)) THEN END ELSE CALL CabPartsSetRotation("joy", "Z", DA)
1110  END

1200  IF OR(ControlActive(JOYPAD_UP), ControlActive(JOYPAD_DOWN)) THEN END ELSE CALL CabPartsSetRotation("joy", "X", DA)
1210  END

1300  IF OR(ControlActive(JOYPAD_UP), ControlActive(JOYPAD_DOWN)) THEN END ELSE CALL CabPartsSetRotation("joy", "X", -1*DA)
1310  END

1400  IF AND(AND(NOT(ControlActive(JOYPAD_UP)), NOT(ControlActive(JOYPAD_DOWN))), AND(NOT(ControlActive(JOYPAD_RIGHT)), NOT(ControlActive(JOYPAD_LEFT)))) THEN GOTO 1410 ELSE END
1410  CALL CabPartsSetRotation("joy", "X", 0)
1420  CALL CabPartsSetRotation("joy", "Z", 0)
1430  END

