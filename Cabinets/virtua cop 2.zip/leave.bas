
100  CALL CabPartsEnable("btn-P1", 1)
110  CALL CabPartsEmission("rank", 0)
120  CALL CabPartsSetRotation("joy", "X", 0)
130  CALL CabPartsSetRotation("joy", "Z", 0)

200  END
