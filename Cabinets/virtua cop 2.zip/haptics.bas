
100  REM Shot Settings (_RIGHT_ or _LEFT_, amlitude-max 1, shot length-sec)

110  CALL ControlRumble("JOYPAD_RIGHT_RUMBLE", 1, 0.05)
120  SLEEP 0.10
130  IF NOT(ControlActive("JOYPAD_R")) THEN END
140  GOTO 110

200  FOR i = 1 TO 10
210  CALL ControlRumble("JOYPAD_RIGHT_RUMBLE", 1, 0.05)
220  SLEEP 0.025
230  'IF NOT(ControlActive("JOYPAD_A")) THEN END
240  NEXT i

300  END