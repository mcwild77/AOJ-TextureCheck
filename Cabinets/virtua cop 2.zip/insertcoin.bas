
  
100 let PartNumber = cabPartsPosition("guns") 
110 gosub 400 

200 end 

400 if PartNumber = -1 then goto 1000 
410 call cabPartsEnable(PartNumber, 0) ' disable 
420 return

1000 call DebugMode(1) 'activate debug mode to see the "error" variable in the insertcoin.bas.debug file. 
1010 let error = "part not found"
